const Questionnaire = require("../models/Questionnaire");

// 🔹 Enregistrer les réponses du questionnaire
exports.submitAnswers = async (req, res) => {
  try {
    const { userId, ...answers } = req.body;

    const newQuestionnaire = new Questionnaire({
      userId: userId,
      ...answers
    });

    await newQuestionnaire.save();
    res.status(201).json({ message: "Réponses enregistrées avec succès !" });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

// 🔹 Récupérer les réponses d'un utilisateur
exports.getUserAnswers = async (req, res) => {
  try {
    const { userId } = req.params;
    const questionnaire = await Questionnaire.findOne({ userId });

    if (!questionnaire) {
      return res.status(404).json({ message: "Aucune réponse trouvée pour cet utilisateur." });
    }

    res.json(questionnaire);
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};
