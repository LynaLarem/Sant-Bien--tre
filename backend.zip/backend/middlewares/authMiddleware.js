const jwt = require("jsonwebtoken");
const User = require("../models/User"); // 🔹 Assure-toi d'importer le modèle utilisateur
require("dotenv").config();

const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Accès non autorisé, token manquant" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log("✅ Utilisateur authentifié :", decoded); // 🔍 Debugging

    // 🔹 Chercher l'utilisateur en base de données
    const user = await User.findById(decoded.userId).select("username");

    if (!user) {
      return res.status(401).json({ message: "Utilisateur introuvable" });
    }

    req.user = { userId: user._id, name: user.username };
    next();
  } catch (error) {
    console.error("❌ Erreur d'authentification :", error);
    return res.status(401).json({ message: "Token invalide" });
  }
};

module.exports = authMiddleware;
