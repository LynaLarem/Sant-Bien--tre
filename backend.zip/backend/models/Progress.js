const mongoose = require("mongoose");

const progressSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  weight: { type: Number, required: true }, // Poids de l'utilisateur
  dailyCalories: { type: Number, required: true }, // Apport calorique du jour
  date: { type: Date, default: Date.now }, // Date de la mise à jour
});

const Progress = mongoose.model("Progress", progressSchema);

module.exports = Progress;