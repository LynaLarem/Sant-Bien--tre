const mongoose = require("mongoose");

const questionnaireSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

  // Informations générales
  sexe: { type: String, required: true },
  weight: { type: Number, required: true },
  height: { type: Number, required: true },
  age: { type: Number, required: true },

  // Activité sportive
  sport: { type: String, required: true }, // Oui / Non
  sportType: { type: String }, // Seulement si sport === "Oui"

  // Habitudes alimentaires et de sommeil
  mealsPerDay: { type: Number, required: true },
  sleepHours: { type: Number, required: true },

  // Informations professionnelles
  work: { type: String, required: true }, // Oui / Non
  workEveryDay: { type: String }, // Seulement si work === "Oui"
  workHours: { type: Number }, // Seulement si work === "Oui"
  sedentaryWork: { type: String }, // Seulement si work === "Oui"

  // Santé et maladies chroniques
  chronicDisease: { type: String, required: true }, // Oui / Non
  chronicDiseaseDetails: { type: String }, // Seulement si chronicDisease === "Oui"

  // Problèmes corporels
  bodyIssues: { type: String, required: true }, // Oui / Non
  bodyIssuesDetails: { type: String } // Seulement si bodyIssues === "Oui"
});

// Export du modèle
module.exports = mongoose.model("Questionnaire", questionnaireSchema);
