const mongoose = require("mongoose");

const ResultSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
    unique: true, // Un utilisateur ne peut avoir qu'un seul résultat
  },
  imc: {
    type: Number,
    required: true,
  },
  weightStatus: {
    type: String,
    required: true,
    enum: ["Maigre", "Normal", "Surpoids", "Obèse"], // Statuts possibles
  },
  idealWeight: {
    type: Number,
    required: true,
  },
  dailyCalories: {
    type: Number,
    required: true,
  },
  daysToIdealWeight: {
    type: Number,
    required: true,
  },
  bodyIssues: {
    type: String,
    default: "", // Problèmes corporels éventuels
  },
  chronicDisease: {
    type: String,
    default: "", // Maladies chroniques éventuelles
  },
}, { timestamps: true });

module.exports = mongoose.model("Result", ResultSchema);
