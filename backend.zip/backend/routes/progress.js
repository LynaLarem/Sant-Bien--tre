const express = require("express");
const router = express.Router();
const Progress = require("../models/Progress");
const authMiddleware = require("../middlewares/authMiddleware");

// Route pour enregistrer les données de mise à jour quotidienne
router.post("/update", authMiddleware, async (req, res) => {
  try {
    const userId = req.user?.userId; // Récupérer l'ID de l'utilisateur à partir du token

    if (!userId) {
      return res.status(400).json({ message: "Utilisateur non authentifié" });
    }

    const { weight, dailyCalories } = req.body;

    // Enregistrer la mise à jour dans la base de données
    const progress = new Progress({
      userId,
      weight,
      dailyCalories,
    });

    await progress.save();

    res.status(201).json({ message: "Données enregistrées avec succès !" });
  } catch (error) {
    console.error("Erreur lors de l'enregistrement des données :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});

// Route pour récupérer l'historique des données de l'utilisateur
router.get("/history", authMiddleware, async (req, res) => {
  try {
    const userId = req.user?.userId;
    if (!userId) {
      return res.status(400).json({ message: "Utilisateur non authentifié" });
    }

    // Récupérer l'historique des mises à jour pour cet utilisateur
    const progressHistory = await Progress.find({ userId }).sort({ date: -1 });
    res.json(progressHistory);
  } catch (error) {
    console.error("Erreur lors de la récupération des données :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});

module.exports = router;