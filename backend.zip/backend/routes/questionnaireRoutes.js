const express = require("express");
const router = express.Router();
const Questionnaire = require("../models/Questionnaire");
const User = require("../models/User"); // Modèle utilisateur
const authMiddleware = require("../middlewares/authMiddleware");

router.post("/", authMiddleware, async (req, res) => {
  try {
    console.log("🔍 Corps de la requête reçue :", req.body);

    const userId = req.user?.userId;
    const userName = req.user?.username; // Assurez-vous que l'attribut correct est utilisé
    const {
      sexe, weight, height, age, sport, sportType,
      mealsPerDay, work, workEveryDay, workHours, sedentaryWork,
      chronicDisease, chronicDiseaseDetails, bodyIssues, bodyIssuesDetails, sleepHours
    } = req.body;

    if (!userId) {
      return res.status(400).json({ message: "Utilisateur non authentifié" });
    }

    // Vérification si l'utilisateur existe bien
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "Utilisateur introuvable" });
    }
    const existingResponse = await Questionnaire.findOne({ userId });
    if (existingResponse) {
      return res.status(400).json({ message: "Vous avez déjà rempli le questionnaire." });
    }

    console.log("✅ Données à sauvegarder :", { 
      userId, sexe, weight, height, age, sport, sportType,
      mealsPerDay, work, workEveryDay, workHours, sedentaryWork,
      chronicDisease, chronicDiseaseDetails, bodyIssues, bodyIssuesDetails, sleepHours 
    });

    // Création d'une nouvelle entrée questionnaire
    const newResponse = new Questionnaire({
      userId,
      sexe,
      weight,
      height,
      age,
      sport,
      sportType: sport === "Oui" ? sportType : null, // Stocke uniquement si l'utilisateur pratique un sport
      mealsPerDay,
      work,
      workEveryDay,
      workHours,
      sedentaryWork,
      chronicDisease,
      chronicDiseaseDetails,
      bodyIssues,
      bodyIssuesDetails,
      sleepHours
    });

    await newResponse.save();

    // Réponse avec le nom et les données de l'utilisateur
    res.status(201).json({ 
      message: "✅ Questionnaire enregistré avec succès !",
      userData: { 
        userId: userId.toString(),
        name: user.username || "Nom inconnu",
        gender: sexe, 
        weight, height, age, sport, sportType,
        mealsPerDay, work, workEveryDay, workHours, sedentaryWork,
        chronicDisease, chronicDiseaseDetails, bodyIssues, bodyIssuesDetails, sleepHours
      }
    });

  } catch (error) {
    console.error("❌ Erreur backend :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});

module.exports = router;
