const express = require("express");
const router = express.Router();
const Result = require("../models/Result");
const authMiddleware = require("../middlewares/authMiddleware");

router.post("/", authMiddleware, async (req, res) => {
  try {
    const userId = req.user?.userId;
    if (!userId) {
      return res.status(400).json({ message: "Utilisateur non authentifié" });
    }

    const {
      imc,
      weightStatus,
      idealWeight,
      dailyCalories,
      daysToIdealWeight,
      bodyIssues = "", // ✅ Valeur par défaut
      chronicDisease = "" // ✅ Valeur par défaut
    } = req.body;

    if (!imc || !weightStatus || !idealWeight || !dailyCalories || !daysToIdealWeight) {
      return res.status(400).json({ message: "Données incomplètes, enregistrement impossible." });
    }

    const existingResult = await Result.findOne({ userId });
    if (existingResult) {
      return res.status(400).json({ message: "Le résultat a déjà été enregistré." });
    }

    const newResult = new Result({
      userId,
      imc,
      weightStatus,
      idealWeight,
      dailyCalories,
      daysToIdealWeight,
      bodyIssues,
      chronicDisease
    });

    await newResult.save();
    res.status(201).json({ message: "✅ Questionnaire enregistré avec succès !", userData: req.body });

  } catch (error) {
    console.error("❌ Erreur backend :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});

router.get('/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await Result.findOne({ userId });
    if (!result) return res.status(404).json({ message: 'Aucun résultat trouvé' });
    res.json(result);
  } catch (error) {
    console.error("❌ Erreur lors de la récupération :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});


module.exports = router;