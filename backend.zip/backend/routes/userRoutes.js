const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const router = express.Router();

// Route d'inscription
router.post("/signup", async (req, res) => {
  try {
    const { username, email, password, phone } = req.body;

    // Vérifier si l'utilisateur existe déjà
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Cet email est déjà utilisé." });
    }

    // Hasher le mot de passe
    const hashedPassword = await bcrypt.hash(password, 10);

    // Créer un nouvel utilisateur
    const newUser = new User({ username, email, password: hashedPassword, phone });
    await newUser.save();

    // ✅ Générer un token JWT
    if (!process.env.JWT_SECRET) {
      console.error("Erreur : JWT_SECRET non défini !");
      return res.status(500).json({ message: "Erreur serveur - Clé JWT manquante" });
    }

    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.status(201).json({ message: "Inscription réussie !", token, userId: newUser._id });
  } catch (error) {
    console.error("Erreur backend (signup) :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});
// Route de connexion
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Vérifier si l'utilisateur existe
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Utilisateur non trouvé" });
    }

    // Vérifier le mot de passe
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Mot de passe incorrect" });
    }

    // ✅ Vérifier si la clé secrète JWT est bien définie
    if (!process.env.JWT_SECRET) {
      console.error("Erreur : JWT_SECRET non défini !");
      return res.status(500).json({ message: "Erreur serveur - Clé JWT manquante" });
    }

    // Générer un token JWT avec une expiration de 1h
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.json({ message: "Connexion réussie", token, userId: user._id });
  } catch (error) {
    console.error("Erreur backend (login) :", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
});



module.exports = router;
