const express = require("express");
const connectDB = require("./config/db");
const cors = require("cors");
const session = require("express-session");
const userRoutes = require("./routes/userRoutes");
const questionnaireRoutes = require("./routes/questionnaireRoutes");
const resultRoutes = require("./routes/results");
const progressRoutes = require("./routes/progress");

require("dotenv").config();

// Connexion à MongoDB
connectDB();

const app = express();

// Configuration de CORS
const corsOptions = {
  origin: "http://localhost:3000",
  credentials: true, // Permet l'envoi des cookies
};
app.use(cors(corsOptions));

// Middleware pour gérer les sessions
app.use(
  session({
    secret: process.env.SESSION_SECRET || "monSecret", // 🔥 Mets ça dans un fichier .env en prod
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // Mettre `secure: true` en production avec HTTPS
  })
);

// Middleware pour parser le JSON
app.use(express.json());

// Routes
app.use("/api/results", resultRoutes);
app.use("/api/users", userRoutes);
app.use("/api/questionnaire", questionnaireRoutes);
app.use("/api/progress", progressRoutes);

// Route de déconnexion
app.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: "Erreur lors de la déconnexion" });
    }
    res.clearCookie("connect.sid"); // Supprime le cookie de session (le nom peut varier)
    return res.json({ message: "Déconnexion réussie" });
  });
});

// Démarrage du serveur
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Serveur démarré sur le port ${PORT}`));
