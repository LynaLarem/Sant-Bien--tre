
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import SignupForm from "./components/SignupForm";
import LoginForm from "./components/LoginForm";
import Questionnaire from "./components/Questionnaire";
import PrivateRoute from "./components/PrivateRoute"; // Import du composant de protection
import Home from "./components/Home";
import ResultPage from "../src/pages/ResultPage";
import DailyUpdateForm from "../src/pages/dailyupdate";
import Accueil from "./components/accueil";
import Navbar from "./components/Navbar";
function App() {
  return (
    <Router>
      <MainContent />
    </Router>
  );
}; 
const MainContent = () => {
  const location = useLocation();
  const showNavbar = location.pathname !== "/login" && location.pathname !== "/signup" && location.pathname !== "/";

  return (
    <>
      {showNavbar && <Navbar />}
      <Routes>
        
        <Route path="/" element={<Home />} />
        <Route path="/accueil" element={<Accueil />} />
        <Route path="/signup" element={<SignupForm />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/questionnaire" element={<PrivateRoute element={<Questionnaire />} />} />
        <Route path="/result" element={<ResultPage />} />
        <Route path="/update" element={<DailyUpdateForm/>}/>
      </Routes>
      </>
  );
};

export default App;
