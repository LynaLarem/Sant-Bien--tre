import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import obeseiteImage from "../assets/obeseité.PNG";
import '../styles/home.css';

  // Assurez-vous que le chemin vers votre fichier CSS est correct

function Home() {
  return (
    <div className="container d-flex flex-column align-items-center justify-content-center vh-100 text-center custom-background">
      <h1 className="mb-4 text-primary fw-bold custom-title">Bienvenue sur notre application</h1>
      <p className="lead text-muted mb-4 custom-text">
        Prenez le contrôle de votre santé avec notre questionnaire interactif.
      </p>

      <div className="bg-light p-4 rounded shadow-lg">
        <img
          src={obeseiteImage}
          alt="Obésité"
          className="img-fluid mb-3 custom-image"
          style={{ maxWidth: "250px" }}
        />
      </div>

      <div className="mt-4 d-flex gap-3">
        <Link to="/login" className="btn btn-outline-primary btn-lg custom-btn">
          Se connecter
        </Link>
        <Link to="/signup" className="btn btn-primary btn-lg custom-btn">
          S'inscrire
        </Link>
      </div>
    </div>
  );
}

export default Home;