import { useState } from "react";
import { useNavigate, Link } from "react-router-dom"; // ✅ Ajout de Link
import "bootstrap/dist/css/bootstrap.min.css";

const LoginForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      console.log("Réponse backend :", data);

      if (response.ok) {
        alert("Connexion réussie !");
        localStorage.setItem("token", data.token);
        navigate("/accueil");
      } else {
        alert(data.message);
      }
    } catch (error) {
      console.error("Erreur de connexion :", error);
      alert("Erreur de connexion au serveur.");
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100 bg-light">
      <div className="card p-4 shadow-lg" style={{ width: "400px", borderRadius: "15px", backgroundColor: "#f3f6f9" }}>
        <h2 className="text-center mb-4" style={{ fontFamily: "Poppins, sans-serif", color: "#2c3e50", fontWeight: "600" }}>
          Connexion
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: "bold", color: "#34495e" }}>Email :</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-control" required />
          </div>

          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: "bold", color: "#34495e" }}>Mot de passe :</label>
            <input type="password" name="password" value={formData.password} onChange={handleChange} className="form-control" required />
          </div>

          <button type="submit" className="btn btn-primary w-100">Se connecter</button>

          {/* ✅ Ajout du lien vers l'inscription */}
          <p className="text-center mt-3">
            Pas encore de compte ? <Link to="/signup" className="text-primary" style={{ textDecoration: "none", fontWeight: "bold" }}>S'inscrire</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
