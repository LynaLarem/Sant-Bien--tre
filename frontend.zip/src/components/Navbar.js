import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      const response = await fetch("http://localhost:5000/logout", {
        method: "POST",
        credentials: "include",
      });

      const data = await response.json();
      console.log("Réponse du serveur :", data.message);

      if (response.ok) {
        localStorage.removeItem("token"); // Supprime le token
        navigate("/login"); // Redirige après suppression
      } else {
        alert("Erreur lors de la déconnexion");
      }
    } catch (error) {
      console.error("Erreur de déconnexion :", error);
      alert("Erreur de connexion au serveur.");
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
      <div className="container">
        <Link className="navbar-brand fw-bold text-primary" to="/">
          Santé & Bien-être
        </Link>
        <div className="d-flex gap-3">
          <Link className="btn btn-outline-primary" to="/questionnaire">
            Questionnaire
          </Link>
          <Link className="btn btn-outline-success" to="/result">
            Résultat
          </Link>
          <Link className="btn btn-outline-warning" to="/update">
            Mise à jour
          </Link>
          <button className="btn btn-danger" onClick={handleLogout}>
            Déconnexion
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
