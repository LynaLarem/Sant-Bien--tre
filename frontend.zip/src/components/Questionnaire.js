import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const Questionnaire = () => {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Vous devez être connecté pour accéder au questionnaire.");
      navigate("/login");
    } else {
      setIsAuthenticated(true);
    }
  }, [navigate]);

  const questions = [
    { text: "Quel est votre sexe ?", type: "radio", name: "sexe", options: ["Homme", "Femme"] },
    { text: "Quel est votre poids en kg ?", type: "number", name: "weight" },
    { text: "Quelle est votre taille en cm ?", type: "number", name: "height" },
    { text: "Quel est votre âge ?", type: "number", name: "age" },
    { text: "Pratiquez-vous une activité sportive ?", type: "radio", name: "sport", options: ["Oui", "Non"] },
    { 
      text: "Quel type de sport pratiquez-vous ?", 
      type: "radio", 
      name: "sportType", 
      options: ["Sédentaire", "Léger", "Modéré", "Intense", "Athlète"], 
      condition: "sport", 
      conditionValue: "Oui" 
    },
    { text: "Combien de fois par jour mangez-vous ?", type: "number", name: "mealsPerDay" },
    { text: "Avez-vous un travail ?", type: "radio", name: "work", options: ["Oui", "Non"] },
    { 
      text: "Travaillez-vous tous les jours ?", 
      type: "radio", 
      name: "workEveryDay", 
      options: ["Oui", "Non"], 
      condition: "work", 
      conditionValue: "Oui" 
    },
    { 
      text: "Combien d'heures travaillez-vous par jour ?", 
      type: "number", 
      name: "workHours", 
      condition: "work", 
      conditionValue: "Oui" 
    },
    { 
      text: "Votre travail est-il sédentaire ?", 
      type: "radio", 
      name: "sedentaryWork", 
      options: ["Oui", "Non"], 
      condition: "work", 
      conditionValue: "Oui" 
    },
    { text: "Avez-vous une maladie chronique ?", type: "radio", name: "chronicDisease", options: ["Oui", "Non"] },
    { 
      text: "Précisez votre maladie chronique", 
      type: "text", 
      name: "chronicDiseaseDetails", 
      condition: "chronicDisease", 
      conditionValue: "Oui" 
    },
    { text: "Avez-vous des problèmes corporels ?", type: "radio", name: "bodyIssues", options: ["Oui", "Non"] },
    { 
      text: "Précisez vos problèmes corporels", 
      type: "text", 
      name: "bodyIssuesDetails", 
      condition: "bodyIssues", 
      conditionValue: "Oui" 
    },
    { text: "Combien d'heures dormez-vous en moyenne par nuit ?", type: "number", name: "sleepHours" }
  ];

  const handleChange = (e) => {
    setAnswers({ ...answers, [questions[currentQuestion].name]: e.target.value });
  };

  const handleNext = () => {
    const currentQ = questions[currentQuestion];

    // Vérification si la réponse est obligatoire et conditionnée
    if (!answers[currentQ.name] && (!currentQ.condition || answers[currentQ.condition] === currentQ.conditionValue)) {
      alert("Veuillez répondre à la question avant de continuer.");
      return;
    }

    try {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        handleSubmit();
      }
    } catch (error) {
      console.error("Erreur lors du passage à la question suivante :", error);
    }
  };

  const handleSubmit = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Votre session a expiré, veuillez vous reconnecter.");
      navigate("/login");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/questionnaire", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(answers)
      });

      const data = await response.json();
      console.log("Réponse backend :", data);

      if (response.ok) {
        if (data.userData) {
          console.log("📊 Debug : userData reçu du backend =", data.userData);
          localStorage.setItem("userResults", JSON.stringify(data.userData));
        }
        navigate("/result");
      } else {
        if (data.message === "Vous avez déjà rempli le questionnaire.") {
          alert("⚠️ Vous avez déjà rempli le questionnaire. Vous allez être redirigé vers vos résultats.");
          navigate("/result"); // Redirige l'utilisateur vers la page des résultats
        } else {
          alert("❌ Une erreur est survenue, veuillez réessayer.");
        }
      }
    } catch (error) {
      console.error("Erreur lors de l'envoi :", error);
      alert("Erreur de connexion avec le serveur.");
    }
  };

  return (
    isAuthenticated && (
      <div className="container d-flex justify-content-center align-items-center vh-100 bg-light">
        <div className="card p-4 shadow-lg" style={{ width: "450px", borderRadius: "15px", backgroundColor: "#fff" }}>
          <h3 className="text-center mb-3" style={{ fontWeight: "bold", color: "#2c3e50" }}>
            Questionnaire Santé
          </h3>
          <div className="progress mb-3">
            <div
              className="progress-bar bg-success"
              role="progressbar"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              aria-valuenow={currentQuestion + 1}
              aria-valuemin="0"
              aria-valuemax={questions.length}
            ></div>
          </div>

          {questions[currentQuestion] && (
            <>
              <p className="mb-3" style={{ fontSize: "18px", fontWeight: "500", color: "#34495e" }}>
                {questions[currentQuestion].text}
              </p>

              {questions[currentQuestion].type === "radio" ? (
                <div className="mb-3">
                  {questions[currentQuestion].options.map((option, index) => (
                    <div key={index} className="form-check">
                      <input
                        type="radio"
                        name={questions[currentQuestion].name}
                        value={option}
                        checked={answers[questions[currentQuestion].name] === option}
                        onChange={handleChange}
                        className="form-check-input"
                      />
                      <label className="form-check-label">{option}</label>
                    </div>
                  ))}
                </div>
              ) : (
                <input
                  type={questions[currentQuestion].type}
                  className="form-control mb-3"
                  value={answers[questions[currentQuestion].name] || ""}
                  onChange={handleChange}
                  required
                />
              )}

              <button onClick={handleNext} className="btn btn-success w-100">
                {currentQuestion < questions.length - 1 ? "Suivant" : "Terminer"}
              </button>
            </>
          )}
        </div>
      </div>
    )
  );
};

export default Questionnaire;
