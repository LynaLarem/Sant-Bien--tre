import { useState } from "react";
import { useNavigate, Link } from "react-router-dom"; 
import "bootstrap/dist/css/bootstrap.min.css";

const SignupForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert("Les mots de passe ne correspondent pas.");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/users/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        alert("Inscription réussie !");
        localStorage.setItem("token", data.token); // ✅ Stocke le token
        navigate("/accueil"); // ✅ Redirige immédiatement vers le questionnaire
      } else {
        alert(data.message);
      }
    } catch (error) {
      alert("Erreur de connexion au serveur.");
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100 bg-light">
      <div className="card p-4 shadow-lg" style={{ width: "400px", borderRadius: "15px", backgroundColor: "#f3f6f9" }}>
        <h2 className="text-center mb-4" style={{ fontFamily: "Poppins, sans-serif", color: "#2c3e50", fontWeight: "600" }}>
          Inscription
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Nom d'utilisateur :</label>
            <input type="text" name="username" value={formData.username} onChange={handleChange} className="form-control" required />
          </div>

          <div className="mb-3">
            <label className="form-label">Email :</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-control" required />
          </div>

          <div className="mb-3">
            <label className="form-label">Mot de passe :</label>
            <input type="password" name="password" value={formData.password} onChange={handleChange} className="form-control" required />
          </div>

          <div className="mb-3">
            <label className="form-label">Confirmer le mot de passe :</label>
            <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} className="form-control" required />
          </div>

          <div className="mb-3">
            <label className="form-label">Numéro de téléphone :</label>
            <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className="form-control" required />
          </div>

          <button type="submit" className="btn btn-success w-100">
            S'inscrire
          </button>

          <p className="text-center mt-3">
            Déjà un compte ? <Link to="/login" className="text-primary" style={{ textDecoration: "none", fontWeight: "bold" }}>Se connecter</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default SignupForm;
