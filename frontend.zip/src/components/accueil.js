import React from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import homeImage from "../assets/home.PNG";

const Accueil = () => {
  const navigate = useNavigate();

  return (
    <div className="container text-center mt-5">
      <h1 className="mb-4">Bienvenue sur notre plateforme Santé & Bien-être</h1>
      <img src={homeImage} alt="Surpoids" className="img-fluid rounded shadow-lg mb-4" style={{ maxWidth: "400px" }} />
      <p className="lead">
        L'obésité et la maigreur sont des problèmes de santé qui nécessitent une prise en charge adaptée.
        Notre questionnaire vous aidera à mieux comprendre votre situation et à obtenir des recommandations personnalisées.
      </p>
    </div>
  );
};

export default Accueil;
