import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const ResultPage = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const storedData = localStorage.getItem("userResults");
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      
      // Calcul des résultats
      const imc = calculateIMC(parsedData.weight, parsedData.height);
      const weightStatus = getWeightStatus(imc);
      const idealWeight = calculateIdealWeight(parsedData.height, parsedData.gender);
      const dailyCalories = calculateCalories(
        parsedData.weight,
        parsedData.height,
        parsedData.age,
        parsedData.gender,
        parsedData.sport,
        parsedData.sportType
      );
      const daysToIdealWeight = calculateDaysToIdealWeight(parsedData.weight, idealWeight, dailyCalories);

      const calculatedData = {
        ...parsedData,
        imc,
        weightStatus,
        idealWeight,
        dailyCalories,
        daysToIdealWeight,
      };

      setUserData(calculatedData);
      setLoading(false);

      // Envoi automatique des résultats au backend
      saveResultsToBackend(calculatedData);
    } else {
      setLoading(false);
    }
  }, []);

  const saveResultsToBackend = async (data) => {
    try {
      const token = localStorage.getItem("token"); // Récupérer le token pour l'authentification
      if (!token) {
        console.warn("❌ Token non trouvé, utilisateur non authentifié.");
        return;
      }

      const response = await fetch("http://localhost:5000/api/results", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.message || "Erreur lors de l'enregistrement.");
      }

      console.log("✅ Résultats enregistrés :", result);
    } catch (err) {
      console.error("❌ Erreur d'enregistrement :", err.message);
      setError("Erreur lors de l'enregistrement des résultats.");
    }
  };


  // Fonction pour calculer l'IMC
  const calculateIMC = (weight, height) => {
    if (!weight || !height) return null;
    const heightInMeters = height / 100;
    return (weight / (heightInMeters * heightInMeters)).toFixed(2);
  };

  // Fonction pour obtenir le statut en fonction de l'IMC
  const getWeightStatus = (imc) => {
    if (!imc) return "Non déterminé";
    if (imc < 18.5) return "Maigre";
    if (imc >= 18.5 && imc < 25) return "Normal";
    return "Obèse";
  };

  // Fonction pour calculer le poids idéal
  const calculateIdealWeight = (height, gender) => {
    if (!height || !gender) return null;
    return gender === "Homme"
      ? (height - 100) - ((height - 150) / 4)
      : (height - 100) - ((height - 150) / 2.5);
  };

  // Fonction pour calculer le besoin calorique quotidien
  const calculateCalories = (weight, height, age, gender, sport, sportType) => {
    if (!weight || !height || !age || !gender) return null;

    // Formule de Mifflin-St Jeor
    const bmr =
      gender === "Homme"
        ? 10 * weight + 6.25 * height - 5 * age + 5
        : 10 * weight + 6.25 * height - 5 * age - 161;

    // Facteur d'activité physique
    const activityFactors = {
      "Sédentaire": 1.2,
      "Léger": 1.375,
      "Modéré": 1.55,
      "Actif": 1.725,
      "Très actif": 1.9
    };

    return Math.round(bmr * (activityFactors[sportType] || 1.2)); // Valeur par défaut : sédentaire
  };

  // Fonction pour estimer les jours pour atteindre le poids idéal
  const calculateDaysToIdealWeight = (currentWeight, idealWeight, dailyCalories) => {
    if (!currentWeight || !idealWeight || !dailyCalories) return null;

    const calorieDeficitPerDay = 500; // Hypothèse : déficit de 500 kcal par jour
    const weightDifference = Math.abs(currentWeight - idealWeight);
    const caloriesNeeded = weightDifference * 7700; // 1 kg = 7700 kcal
    return Math.ceil(caloriesNeeded / calorieDeficitPerDay);
  };

  if (loading) {
    return <p className="text-center">Chargement des résultats...</p>;
  }

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow-lg">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">📊 Résultats du Questionnaire</h2>

              {userData ? (
                <ul className="list-group list-group-flush">
                  <li className="list-group-item"><strong>👤 Nom :</strong> {userData.name}</li>
                  <li className="list-group-item"><strong>📏 IMC :</strong> {userData.imc ?? "Non calculé"}</li>
                  <li className="list-group-item"><strong>⚖️ Statut :</strong> {userData.weightStatus ?? "Non déterminé"}</li>
                  <li className="list-group-item"><strong>🏋️‍♂️ Poids Idéal :</strong> {userData.idealWeight ?? "Non calculé"} kg</li>
                  <li className="list-group-item"><strong>🔥 Besoin calorique quotidien :</strong> {userData.dailyCalories ?? "Non calculé"} kcal</li>
                  <li className="list-group-item"><strong>📆 Jours estimés pour atteindre le poids idéal :</strong> {userData.daysToIdealWeight ?? "Non calculé"} jours</li>
                  <li className="list-group-item">
                    <strong>💪 Activité sportive :</strong> {userData.sportType ? `Vous pratiquez un sport de type ${userData.sportType}` : "Non renseigné"}
                  </li>
                  <li className="list-group-item">
                    <strong>💼 Travail :</strong> {userData.sedentaryWork ? `Votre travail est de type ${userData.sedentaryWork === "Oui" ? "sédentaire" : "non sédentaire"}` : "Non renseigné"}
                  </li>
                  <li className="list-group-item">
                    <strong>🩺 Problèmes corporels :</strong> {userData.bodyIssuesDetails ? `Problèmes corporels : ${userData.bodyIssuesDetails}` : "Non renseigné"}
                  </li>
                  <li className="list-group-item">
                    <strong>🩺 Maladie chronique :</strong> {userData.chronicDiseaseDetails ? `Maladie chronique : ${userData.chronicDiseaseDetails}` : "Non renseigné"}
                  </li>
                </ul>
              ) : (
                <p className="text-warning">Aucun résultat en base. Veuillez remplir le questionnaire.</p>
              )}

              <button
                onClick={() => navigate("/update")}
                className="btn btn-secondary mt-3 w-100"
              >
                Mettre à jour mes données
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultPage;
