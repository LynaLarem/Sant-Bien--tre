import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { calculateCalories } from "../utils/calculations";
import Chart from "chart.js/auto"; 

const DailyUpdateForm = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [dailyCalories, setDailyCalories] = useState(0);
  const [currentWeight, setCurrentWeight] = useState(0);
  const [remarks, setRemarks] = useState("");
  const [weightHistory, setWeightHistory] = useState([]);
  const [caloriesHistory, setCaloriesHistory] = useState([]);
  const [initialWeight, setInitialWeight] = useState(null);
  const [recommendedCalories, setRecommendedCalories] = useState(null);

  const weightChartRef = useRef(null);
  const caloriesChartRef = useRef(null);

  useEffect(() => {
    const storedResults = localStorage.getItem("userResults");

    if (storedResults) {
      const parsedResults = JSON.parse(storedResults);
      setUserData(parsedResults);
      setInitialWeight(parsedResults.weight);
      setRecommendedCalories(parsedResults.dailyCalories);
      const calculatedCalories = calculateCalories(
        parsedResults.weight,
        parsedResults.height,
        parsedResults.age,
        parsedResults.gender,
        parsedResults.sport,
        parsedResults.sportType
      );
      setRecommendedCalories(calculatedCalories);
    } else {
      navigate("/questionnaire");
    }

    fetchProgressHistory();
  }, [navigate]);

  const fetchProgressHistory = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:5000/api/progress/history", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la récupération de l'historique");
      }

      const history = await response.json();
      setWeightHistory(history.map((entry) => ({ date: entry.date, weight: entry.weight })));
      setCaloriesHistory(history.map((entry) => ({ date: entry.date, calories: entry.dailyCalories })));

      drawGraph(history);
    } catch (error) {
      console.error("Erreur:", error);
      alert("Erreur lors de la récupération de l'historique");
    }
  };

  const drawGraph = (history) => {
    const weightLabels = history.map(entry => new Date(entry.date).toLocaleDateString());
    const weightData = history.map(entry => entry.weight);
    const caloriesData = history.map(entry => entry.dailyCalories);

    const weightCtx = weightChartRef.current?.getContext("2d");
    if (weightCtx) {
      if (window.myWeightChart) {
        window.myWeightChart.destroy();
      }
      window.myWeightChart = new Chart(weightCtx, {
        type: "line",
        data: {
          labels: weightLabels,
          datasets: [{ label: "Poids (kg)", data: weightData, borderColor: "blue", fill: false, tension: 0.1 }],
        },
        options: { responsive: true, scales: { x: { title: { display: true, text: "Date" } }, y: { title: { display: true, text: "Poids (kg)" } } } },
      });
    }

    const caloriesCtx = caloriesChartRef.current?.getContext("2d");
    if (caloriesCtx) {
      if (window.myCaloriesChart) {
        window.myCaloriesChart.destroy();
      }
      window.myCaloriesChart = new Chart(caloriesCtx, {
        type: "line",
        data: {
          labels: weightLabels,
          datasets: [{ label: "Calories consommées", data: caloriesData, borderColor: "green", fill: false, tension: 0.1 }],
        },
        options: { responsive: true, scales: { x: { title: { display: true, text: "Date" } }, y: { title: { display: true, text: "Calories" } } } },
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!userData) return;

    const feedback = `Apport calorique du jour : ${dailyCalories} kcal. `;

    // Comparaison avec les besoins recommandés
    let caloriesRemark = "";
    if (recommendedCalories) {
      const diff = dailyCalories - recommendedCalories;
      if (diff < -200) {
        caloriesRemark = "⚠️ Vous mangez trop peu de calories par rapport à vos besoins.";
      } else if (diff > 200) {
        caloriesRemark = "⚠️ Vous consommez trop de calories aujourd’hui.";
      } else {
        caloriesRemark = "✅ Votre apport calorique est bien équilibré aujourd’hui.";
      }
    }

    setRemarks(`${feedback}\n${caloriesRemark}`);

    const newProgress = { weight: currentWeight, dailyCalories };
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:5000/api/progress/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newProgress),
      });

      if (!response.ok) {
        throw new Error("Échec de l'envoi des données");
      }

      const data = await response.json();
      console.log(data.message);
      setRemarks(feedback);

      fetchProgressHistory();
    } catch (error) {
      console.error("Erreur lors de l'envoi des données :", error);
      alert("Erreur lors de l'envoi des données");
    }
  };

  const handleCaloriesChange = (e) => setDailyCalories(e.target.value);
  const handleWeightChange = (e) => setCurrentWeight(e.target.value);

  return (
    <div className="container mt-5">
      <h2 className="text-center">Mise à jour quotidienne</h2>
      <form onSubmit={handleSubmit} className="card p-3 shadow-lg">
        <div className="mb-3">
          <label className="form-label">Apport calorique du jour (kcal)</label>
          <input type="number" className="form-control" value={dailyCalories} onChange={handleCaloriesChange} required />
          {recommendedCalories && <small className="text-muted">Votre besoin recommandé : {recommendedCalories} kcal</small>}
        </div>
        <div className="mb-3">
          <label className="form-label">Poids actuel (kg)</label>
          <input type="number" className="form-control" value={currentWeight} onChange={handleWeightChange} required />
          {initialWeight && <small className="text-muted">Poids initial : {initialWeight} kg</small>}
        </div>
        <button type="submit" className="btn btn-primary w-100">Mettre à jour</button>
      </form>
      {remarks && <div className="alert alert-info mt-3"><p>{remarks}</p></div>}
      <canvas ref={weightChartRef} id="weightChart" width="400" height="200"></canvas>
      <canvas ref={caloriesChartRef} id="caloriesChart" width="400" height="200"></canvas>
    </div>
  );
};

export default DailyUpdateForm;
