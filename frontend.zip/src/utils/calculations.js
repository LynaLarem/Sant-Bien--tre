// utils/calculations.js

// Calcul de l'IMC
export const calculateIMC = (weight, height) => {
    if (!weight || !height) return null;
    const heightInMeters = height / 100;
    return (weight / (heightInMeters * heightInMeters)).toFixed(2);
  };
  
  // Déterminer le statut de poids selon l'IMC
  export const getWeightStatus = (imc) => {
    if (!imc) return "Non déterminé";
    if (imc < 18.5) return "Maigre";
    if (imc >= 18.5 && imc < 25) return "Normal";
    return "Obèse";
  };
  
  // Calcul du poids idéal
  export const calculateIdealWeight = (height, gender) => {
    if (!height || !gender) return null;
    return gender === "Homme"
      ? (height - 100) - ((height - 150) / 4)
      : (height - 100) - ((height - 150) / 2.5);
  };
  
  // Calcul du besoin calorique quotidien
  export const calculateCalories = (weight, height, age, gender, sport, sportType) => {
    if (!weight || !height || !age || !gender) return null;
  
    const bmr = gender === "Homme"
      ? 10 * weight + 6.25 * height - 5 * age + 5
      : 10 * weight + 6.25 * height - 5 * age - 161;
  
    const activityFactors = {
      "Sédentaire": 1.2,
      "Léger": 1.375,
      "Modéré": 1.55,
      "Actif": 1.725,
      "Très actif": 1.9
    };
  
    return Math.round(bmr * (activityFactors[sportType] || 1.2));
  };
  
  // Calcul du nombre de jours pour atteindre le poids idéal
  export const calculateDaysToIdealWeight = (currentWeight, idealWeight, dailyCalories) => {
    if (!currentWeight || !idealWeight || !dailyCalories) return null;
  
    const calorieDeficitPerDay = 500;
    const weightDifference = Math.abs(currentWeight - idealWeight);
    const caloriesNeeded = weightDifference * 7700; // 1 kg = 7700 kcal
    return Math.ceil(caloriesNeeded / calorieDeficitPerDay);
  };
  